# tsq
Python library for validating the quality of time series data
